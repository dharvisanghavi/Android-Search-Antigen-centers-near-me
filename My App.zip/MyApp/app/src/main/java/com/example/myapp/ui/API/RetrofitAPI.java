package com.example.myapp.ui.API;

import com.example.myapp.DataModal;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;

import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface RetrofitAPI {

    @POST("/posts")
    @Headers({"Content-Type: application/x-www-form-urlencoded"})
    //on below line we are creating a method to post our data.
    Call<List<DataModal>> createPost(@Body DataModal dataModal);
}

