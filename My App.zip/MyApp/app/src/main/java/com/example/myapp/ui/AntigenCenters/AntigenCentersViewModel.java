package com.example.myapp.ui.AntigenCenters;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;


public class AntigenCentersViewModel extends ViewModel {
    private final MutableLiveData<String> Antigen_centersText;

    public AntigenCentersViewModel() {
        Antigen_centersText = new MutableLiveData<>();
        Antigen_centersText.setValue("This is gallery fragment");
    }

    public LiveData<String> getText() {
        return Antigen_centersText;
    }
}