package com.example.myapp.ui.API;

public class list<T> {
}
