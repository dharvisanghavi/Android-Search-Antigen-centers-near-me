/*
package com.example.myapp.ui.AntigenCenters;

import android.content.Context;
import android.view.View;

import androidx.fragment.app.Fragment;

import android.widget.AdapterView;
import android.widget.Toast;

public abstract class AntigenCentersFragment extends Fragment implements AdapterView.OnItemSelectedListener, AntigenCenterFragment {

        String[] courses = { "C", "Data structures",
                "Interview prep", "Algorithms",
                "DSA with java", "OS" };

    // Performing action when ItemSelected
    // from spinner, Overriding onItemSelected method
    @Override
    public void onItemSelected(View arg0, View arg1,
                               int position,
                               long id)
    {


        Toast.makeText(getApplicationContext(),
                courses[position],
                Toast.LENGTH_LONG)
                .show();
    }

    private Context getApplicationContext() {
        return null;
    }

    public void onNothingSelected(View arg0)
        {
            // Auto-generated method stub
        }


    private void setContentView(int activity_main) {
    }

    @Override
    public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(android.widget.AdapterView<?> parent) {

    }
}
*/
package com.example.myapp.ui.AntigenCenters;

import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapp.DataModal;
import com.example.myapp.R;
import com.example.myapp.ui.API.RetrofitAPI;

import androidx.annotation.NonNull;

import androidx.fragment.app.Fragment;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AntigenCentersFragment extends Fragment {
    EditText pincode;
    Button button;
    String stateText,CityText;

    //private FragmentAntigencentersBinding binding;
    String[] state = { "Gujarat", "Andhra Pradesh", "Arunachal Pradesh", "Assam,Bihar", "Karnataka", "Kerala", "Chhattisgarh", "Uttar Pradesh", "Goa", "Haryana",

            "Himachal Pradesh", "JammuKashmir",
            "Jharkhand ",
            "West Bengal",

            "Madhya Pradesh",

            "Maharashtra",

            "Manipur",

            "Meghalaya",

            "Mizoram",

            "Nagaland",

            "Orissa",

            "Punjab",

            "Rajasthan",

            "Sikkim",

            "Tamil Nadu",

            "Telangana",

            "Tripura",

            "Uttarakhand"};
    String[] city = {"Ahmedabad,","Vadodara1",
            "Anand",

            "Gandhinagar",
            "Kutch",
            "Rajkot",
            "Surat", "Mumbai", "Aurangabad",
            "Nashik",
            "Thane",
            "Sangli",
            "Amaravati",
            "Chandrapur",
            "Pune",
            "Nagpur",
            "Kolhapur",
            "Ratnagiri",
    };


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_antigencenters, container, false);


        Spinner spinner = (Spinner) v.findViewById(R.id.spinner1);
        ArrayAdapter<String> LTRadapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, state);
        LTRadapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(LTRadapter);
        stateText = spinner.getSelectedItem().toString();


        Spinner spinner1 = (Spinner) v.findViewById(R.id.spinner2);
        ArrayAdapter<String> LRadapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, city);
        LTRadapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner1.setAdapter(LRadapter);
        CityText = spinner1.getSelectedItem().toString();




        pincode = (EditText) v.findViewById(R.id.text_pincode);
        pincode.setInputType(InputType.TYPE_CLASS_NUMBER);


        pincode.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendMessage();
                    handled = true;
                }
                return handled;
            }

            private void sendMessage() {
            }


        });
        button = (Button) v.findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //String poncode=pincode.getText().toString();
                postData(stateText,CityText,pincode.getText().toString());
            }
        });
        return v;

    }


    private void postData(String state, String city,String pincode) {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.8/get_center.php/")

                .addConverterFactory(GsonConverterFactory.create())

                .build();
        RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);
        DataModal modal = new DataModal(state,city,pincode);

        Call<List<DataModal>> call = retrofitAPI.createPost(modal);
System.out.println("user Info :" + response.body().getAsJsonObject());
//                    try {
//                        //JSONObject json = new JSONObject(response.body().toString());
//                        Log.d("res", response.body().toString());
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
                }


                //In this point we got our hero list
                //thats damn easy right ;)
               // List<Hero> heroList = response.body();

                //now we can do whatever we want with this list
            }

            @Override
            public void onFailure(Call<List<DataModal>> call, Throwable t) {
                //handle error or failure cases here
                Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
